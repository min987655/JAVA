package Action;

import Login.EnterFrame2;

public class MainClient2 {

	public static void main(String[] args) {
		new EnterFrame2();
	}
}
