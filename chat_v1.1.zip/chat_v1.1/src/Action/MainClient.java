package Action;

import Login.EnterFrame;

public class MainClient {

	public static void main(String[] args) {
		new EnterFrame();
	}
}
