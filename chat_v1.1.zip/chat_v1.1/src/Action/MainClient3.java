package Action;

import Login.EnterFrame3;

public class MainClient3 {

	public static void main(String[] args) {
		new EnterFrame3();
	}
}
